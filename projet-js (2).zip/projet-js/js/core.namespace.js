(() => {
  "use strict";
  window.EO = window.EO || {};
})();
